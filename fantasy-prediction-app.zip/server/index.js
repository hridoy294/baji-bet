
const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

const DATA_FILE = path.join(__dirname, "predictions.json");

function savePrediction(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

function readPredictions() {
  if (!fs.existsSync(DATA_FILE)) return {};
  const raw = fs.readFileSync(DATA_FILE);
  return JSON.parse(raw);
}

app.get("/api/predictions", (req, res) => {
  const data = readPredictions();
  res.json(data);
});

app.post("/api/predictions", (req, res) => {
  const { userId, predictions } = req.body;
  if (!userId || !predictions) {
    return res.status(400).json({ error: "userId and predictions required" });
  }

  const all = readPredictions();
  all[userId] = predictions;
  savePrediction(all);

  res.json({ success: true });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
